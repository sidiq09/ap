# ===============================================================
# Author: Firdauz Fanani
# Email: firdauzfanani@gmail.com
# Twitter: @firdauzfanani
# ===============================================================


# Telegram credentials:
telegram_token = '723437754:AAGtGSR6MUqe2mLHEYRm8MpsThaodUg7Co8'

# Google Maps credentials:
maps_token = 'AIzaSyCeFEqaXj_7P1xeCcV3zC2h1ldJ9GEj4GA'
